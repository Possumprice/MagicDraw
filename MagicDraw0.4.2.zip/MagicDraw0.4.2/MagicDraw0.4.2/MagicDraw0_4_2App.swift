//
//  MagicDraw0_4_2App.swift
//  MagicDraw0.4.2
//
//  Created by Lincoln Price on 4/15/24.
//



@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate { }
