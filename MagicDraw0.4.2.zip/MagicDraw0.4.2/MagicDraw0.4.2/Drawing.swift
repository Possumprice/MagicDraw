//
//  Drawing.swift
//  MagicDraw0.4.2
//
//  Created by Lincoln Price on 4/15/24.
//

import Foundation
import PencilKit

struct Drawing: Identifiable {
    var id = UUID()
    let title: String
    let drawing: PKDrawing
    let image: UIImage
    let date: Date
}



enum DrawingType: String, CaseIterable {
    case base = ""
    case car = "Car"
    case house = "House"
    case dog = "Dog"
}
