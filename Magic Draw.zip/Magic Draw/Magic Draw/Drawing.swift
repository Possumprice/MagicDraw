//
//  Drawing.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/1/24.
//

import Foundation
import UIKit
import PencilKit

struct Drawing {
    let title: String
    let drawing: PKDrawing
    let image: UIImage
}

enum DrawingType: String, CaseIterable {
    case base = ""
    case car = "Car"
    case house = "House"
    case dog = "Dog"
}
