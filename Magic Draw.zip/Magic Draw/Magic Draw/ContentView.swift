//
//  ContentView.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/1/24.
//

import SwiftUI
import PencilKit

struct ContentView: View {
    
    @State var drawing: Drawing?
    
    @State private var canvas = PKCanvasView()
    @State private var isSpeaking = false
    @State private var drawingType: DrawingType = .base
    @State private var isSharing = false
    
    var body: some View {
        NavigationView {
            ZStack {
                CanvasView(canvas: $canvas, onSaved: saveDrawing).padding(10.0).background(Color.black).navigationBarTitle(Text("Magic Draw"), displayMode: .inline).navigationBarItems(
                    leading: HStack {
                        Button {
                            isSpeaking = true
                        } label: {
                            Image(systemName: "mic")
                        }.popover(isPresented: $isSpeaking, arrowEdge: .top)
                        {
                            SpeakingView()
                        }
                        Picker("Drawing Type", selection: $drawingType) {
                            Text("Car").tag(DrawingType.car)
                            Text("House").tag(DrawingType.house)
                            Text("Dog").tag(DrawingType.dog)
                        }.pickerStyle(.menu)
                    }, trailing: HStack {
                        Button(action: shareDrawing) {
                            Image(systemName: "square.and.arrow.up")
                        }.sheet(isPresented: $isSharing) {
                            ShareView(activityItems: [drawing?.image as Any], excludedActivityTypes: [])
                        }
                        Button(action: deleteDrawing) {
                            Image(systemName: "trash")
                        }
                        Button(action: undoDelete) {
                            Image(systemName: "arrow.uturn.left")
                        }
                    })
                
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct SpeakingView:View {
    
    
    var body: some View {
        Text("").foregroundColor(Color.black).toolbar {
            ToolbarItemGroup(placement: .topBarLeading) {
                Button {
                    
                } label: {
                    Image("microphone")
                }
            }
        }
    }
    
}

private extension ContentView {
    func saveDrawing() {
        //create image representation of the drawing
        let image = canvas.drawing.image(from: canvas.bounds, scale: UIScreen.main.scale)
        //create drawing
        let drawing = Drawing(title: "placeholder", drawing: canvas.drawing, image: image)
        //update state variable
        self.drawing = drawing
    }
    
    func deleteDrawing() {
        canvas.drawing = PKDrawing()
    }
    
    func undoDelete() {
        if let drawing = drawing {
            canvas.drawing = drawing.drawing
        }
    }
    
    func shareDrawing() {
        if drawing != nil {
            isSharing = true
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
