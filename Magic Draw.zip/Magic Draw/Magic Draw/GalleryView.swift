//
//  GalleryView.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/5/24.
//

import Foundation
import UIKit
import PencilKit
import SwiftUI

struct GalleryView: View {
    @ObservedObject var drawings: DrawingList
    
    static private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(drawings.drawingList, id: \.id) {
                    Drawing in
                    NavigationLink(destination: DisplayView(drawing: Drawing, drawings: drawings)) {
                        Text(Drawing.title)
                        Image(uiImage:Drawing.image).aspectRatio(contentMode:.fit)
                        Text(Self.dateFormatter.string(from:Drawing.date)) 
                    }
                }.onDelete(perform: { indexSet in
                    //fill in
                })
            }
        }
    }
}
