//
//  CanvasView.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/1/24.
//

import SwiftUI
import PencilKit

struct CanvasView {
  @Binding var canvasView: PKCanvasView
  let onSaved: () -> Void
  @State var toolPicker = PKToolPicker()
}

extension CanvasView: UIViewRepresentable {
  func makeUIView(context: Context) -> PKCanvasView {
    canvasView.tool = PKInkingTool(.pen, color: .gray, width: 10)
    #if targetEnvironment(simulator)
      canvasView.drawingPolicy = .anyInput
    #endif
    canvasView.delegate = context.coordinator
    showToolPicker()
    return canvasView
  }

  func updateUIView(_ uiView: PKCanvasView, context: Context) {}

  func makeCoordinator() -> Coordinator {
    Coordinator(canvasView: $canvasView, onSaved: onSaved)
  }
}

private extension CanvasView {
  func showToolPicker() {
      
      //tie tool picker's visibility to whether the canvas view is active
    toolPicker.setVisible(true, forFirstResponder: canvasView)
      
      //ensure canvas view is notified of any changes to the tool picked
    toolPicker.addObserver(canvasView)
      
      //ask canvas view to become first responder, making toolpicker visible
    canvasView.becomeFirstResponder()
  }
}

//communicates between UI view and canvas view
class Coordinator: NSObject {
  var canvasView: Binding<PKCanvasView>
  let onSaved: () -> Void

  init(canvasView: Binding<PKCanvasView>, onSaved: @escaping () -> Void) {
    self.canvasView = canvasView
    self.onSaved = onSaved
  }
}

extension Coordinator: PKCanvasViewDelegate {
    //called whenever the contents of the canvas view change
  func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
    if !canvasView.drawing.bounds.isEmpty {
      onSaved()
    }
  }
}


