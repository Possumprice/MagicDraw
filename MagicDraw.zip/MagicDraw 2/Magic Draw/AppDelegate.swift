//
//  Magic_DrawApp.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/1/24.
//

import SwiftUI
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {}
