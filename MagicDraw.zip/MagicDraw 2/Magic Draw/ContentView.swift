//
//  ContentView.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/1/24.
//

// 

import SwiftUI
import PencilKit

struct DrawingView: View {
    
    //when returning here to edit, set drawing to chosen one
    @State var drawing: Drawing?
    
    @State private var canvasView = PKCanvasView()
    @State private var isSpeaking = false
    @State private var isViewing = false
    @State private var drawingType: DrawingType = .base
    @State private var selectedDrawing = -1
    @State private var isSharing = false
    @State private var isAdding = false
    @State private var isShowingGallery = false
    
    @State private var searchText = ""
    
    @State private var density = 10.0
    @State private var isShowingDensity = false
    
    @State var addT:String = ""
    @ObservedObject var drawings: DrawingList = DrawingList()
    
    var body: some View {
        NavigationView {
            HStack {
                VStack {
                    
                    //Gallery button, will change to layers, move down, and put gallery in image part
                    Button {
                        isShowingGallery = true
                    } label: {
                        Image(systemName: "square.stack.3d.up").animation(.easeInOut).font(.title)
                    }.popover(isPresented: $isShowingGallery, arrowEdge: .top) {
                        GalleryView(drawings: drawings, selected: addT, onSelected: setDrawing)
                    }.padding()
                    
                    //Canvas options
                    Button {
                        
                    } label: {
                        Image(systemName: "rectangle").font(.title)
                    }.padding()
                    
                    //Import image
                    Button {
                        
                    } label: {
                        Image(systemName: "camera.on.rectangle").font(.title)
                    }.padding()
                    
                    //Density option
                    Button {
                        isShowingDensity = true
                    } label: {
                        Image(systemName: "squareshape.dotted.squareshape").font(.title)
                    }.popover(isPresented: $isShowingDensity, arrowEdge: .top) {
                            VStack {
                                Text("Density: \(density, specifier: "%.1f")")
                                Slider(value: $density, in: 1...100)
                            }.padding()
                        
                    }.padding()
                    
                    //Center canvas
                    Button {
                        
                    } label: {
                        Image(systemName: "grid").font(.title)
                    }.padding()
                    
                    //Perspective mode
                    Button {
                        
                    } label: {
                        Image(systemName: "perspective").font(.title)
                    }.padding()
                    
                    //settings
                    Button {
                        
                    } label: {
                        Image(systemName: "gearshape").font(.title)
                    }.padding()
                    
                    //Move to top
                    /*
                    Button {
                        isSpeaking = true
                    } label: {
                        Image(systemName: "mic").animation(.easeInOut).font(.title)
                    }.popover(isPresented: $isSpeaking, arrowEdge: .top)
                    {
                        SpeakingView()
                    }.padding()
                     */
                    
                    /*
                    Picker("Drawing Type", selection: $drawingType) {
                        Text("Choose a drawing").tag(DrawingType.base)
                        Text("Car").tag(DrawingType.car)
                        Text("House").tag(DrawingType.house)
                        Text("Dog").tag(DrawingType.dog)
                    }.pickerStyle(.navigationLink)
                    Spacer()
                     */
                    
                    //save to gallery
                    Button(action: {
                        isAdding = true
                    }) {
                        Image(systemName: "plus.app").animation(.easeInOut).font(.title)
                    }.padding()
                     
                    //share drawing
                    Button(action: shareDrawing) {
                        Image(systemName: "square.and.arrow.up").animation(.easeInOut).font(.title)
                    }.sheet(isPresented: $isSharing) {
                        ShareView(activityItems: [drawing?.image as Any], excludedActivityTypes: [])
                    }.padding()
                    
                    //delete drawing/clear canvas
                    Button(action: deleteDrawing) {
                        Image(systemName: "trash").animation(.easeInOut).font(.title)
                    }.padding()
                  
                    //undo deletion
                    Button(action: undoDelete) {
                        Image(systemName: "arrow.uturn.left").animation(.easeInOut).font(.title)
                    }.padding()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    
                }
                
                VStack {
                    
                        //tapping removes toolpicker for some reason, needs fix
                    //would like
                    HStack {
                        HStack {
                            Spacer()
                            TextField("Summer photograph of a stag...", text: $searchText).background(Color.white).font(.title).padding()
                            
                            //really don't need microphone
                            Button {
                                
                            } label: {
                                Image(systemName: "mic").font(.title)
                            }.padding()
                        }
                        Text("|").font(.largeTitle)
                        Button {
                            generate(t: self.searchText)
                        } label: {
                            Text("Generate").font(.title)
                        }.padding()
                        
                        Text("|").font(.largeTitle)
                       
                        Button {
                            test() //implement
                        } label: {
                            Image(systemName: "play").font(.title)
                        }.padding()
                        Spacer()
                        
                        
                    }
                    
                    CanvasView(canvasView: $canvasView, onSaved: saveDrawing).padding(20.0).background(Color.gray)
                }
                
                
            }
            
            .alert("Save Drawing", isPresented: $isAdding, actions: {
                TextField("Title", text: $addT)
                Button("Add", action: {
                    addDrawing(t:addT)
                    isAdding = false
                })
                Button("Cancel", role: .cancel, action: {
                    isAdding = false
                })
            }, message: { Text("Enter title")})
             
        }.navigationViewStyle(StackNavigationViewStyle())
    }
    
    /*
    var searchResults: [String] {
        
    }
     */
}

private extension DrawingView {
    
    //CODE HERE
    func test() {
        
    }
    
    //machine learning code here @SOHEIL
    func generate(t:String) {
        /*
         CODE
         */
    }
    
    //convert audio to text
    func getSpeak() {
        
    }
    
    func addDrawing(t:String) {
        let image = canvasView.drawing.image(from: canvasView.bounds, scale: UIScreen.main.scale)
        drawings.addNewDrawing(t, canvasView.drawing, image)
    }
    
    func saveDrawing() {
        //create image representation of the drawing
        let image = canvasView.drawing.image(from: canvasView.bounds, scale: UIScreen.main.scale)
        //create drawing
        let drawing = Drawing(title: "placeholder", drawing: canvasView.drawing, image: image, date: .now)
        //update state variable
        self.drawing = drawing
    }
    
    func deleteDrawing() {
        canvasView.drawing = PKDrawing()
    }
    
    func undoDelete() {
        if let drawing = drawing {
            canvasView.drawing = drawing.drawing
        }
    }
    
    func shareDrawing() {
        if drawing != nil {
            isSharing = true
        }
    }
    
    func setDrawing(at draw: Drawing) {
        canvasView.drawing = draw.drawing
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        DrawingView()
    }
}
