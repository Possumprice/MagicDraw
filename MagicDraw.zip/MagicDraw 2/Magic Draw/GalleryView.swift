//
//  GalleryView.swift
//  Magic Draw
//
//  Created by Lincoln Price on 4/5/24.
//


 import Foundation
 import UIKit
 import PencilKit
 import SwiftUI
 
 struct GalleryView: View {
     @ObservedObject var drawings: DrawingList
     let selected: String
     let onSelected: ((Drawing) -> Void)?
     
     static private let dateFormatter: DateFormatter = {
         let formatter = DateFormatter()
         formatter.dateStyle = .medium
         return formatter
     }()
 
 
 
     var body: some View {
         VStack {
             Text("Double-tap to select a drawing").font(.headline).padding(.top)
             ScrollView(.vertical){
                 VStack {
                     ForEach(drawings.drawingList, id: \.id) {
                         Drawing in
                         Image(uiImage: Drawing.image).resizable().aspectRatio(contentMode: .fit).padding(5).scaleEffect(Drawing.title == selected ? 1.05 : 0.95).animation(.easeInOut).onTapGesture(count: 2) {
                             onSelected?(Drawing)
                         }
                     }
                 }
             }.padding([.leading, .bottom, .trailing], 10)
         }
     }
}
 
